

<div class="footer">
		<div class="col-md-4 footer-left-agileits">
			<h3>Address</h3>
				<ul>
					<li><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Woodvale Grove, Westlands - Nairobi, Kenya</li>
					<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span><a href="mailto:info@Companyonline.net">info@example.com</a></li>
					<!-- <li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +(254) 754 235 535</li> -->
				</ul>
		</div>
		<div class="col-md-4 footer-left-agileinfo">
			<h3>Get In Touch</h3>
			<p>Follow us, Tweet us, Tag us, Pin us.</p>
				<ul class="social-icons">
					<li><a href="#" class="icon icon-border facebook"></a></li>
					<li><a href="#" class="icon icon-border twitter"></a></li>
					<li><a href="#" class="icon icon-border instagram"></a></li>
					<li><a href="#" class="icon icon-border pinterest"></a></li>
				</ul>
		</div>
		<div class="col-md-4 footer-left-w3-agileits">
			<h3>Newsletter</h3>
			<p>Subscribe to our newsletter and be the first to know what we are upto.</p>
				<form action="functions/subscribe.php" method="post">
					<input type="email" name="email" placeholder="Your email..." required="">
					<input type="submit" value=" " name="submit">
				</form>
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //footer --> 
	<div class="copyright-w3-agile">
		<div class="container">
			<p>© 2018 company | All rights reserved.</p>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
</body>
</html>